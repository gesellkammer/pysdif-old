from pysdif import *
import numpy


def as_sdiffile(s):
    if isinstance(s, SdifFile):
        return s
    return SdifFile(s)

def convert_1TRC_to_RBEP(sdiffile):
    sdiffile = as_sdiffile(sdiffile)
    filename = sdiffile.name
    outfile = os.path.splitext(filename)[0] + "-RBEP.sdif"
    o = SdifFile(outfile, 'w', 'RBEP')
    def data_convert_1TRC_RBEP(d):
        # normally, 1TRC matrices have index, freq, amp, phase
        # but Spear, for example, add columns to the 1TRC definition to store time offset
        # According to the IRCAM people, this is actually the right thing to do, instead
        # of defining a new frame and matrix type, extend the existing one with bandwidth and offset
        # But Loris and the Loris UGens in Supercollider expect to read RBEP frames, so
        # the discussion is only theoretical: those SDIF files exist out there and we want to
        # be able to read them.
        num_rows = len(d)
        if num_rows > 0:
            empty_rows = numpy.zeros((num_rows, 2), dtype=d.dtype)
            out = numpy.hstack((d[:,:4], empty_rows))
            if not out.flags.contiguous:
                out = out.copy()
            return out
        return d # an empty array
    for frame0 in sdiffile:
        if frame0.signature == '1TRC':
            frame1 = o.new_frame("RBEP", frame0.time)
            data = frame0.get_matrix_data()
            new_data = data_convert_1TRC_RBEP(data)
            frame1.add_matrix("RBEP", new_data)
            frame1.write()
    o.close()

def add_type_definitions(sdiffile, frame_types=None, matrix_types=None, inplace=False):
    infile = as_sdiffile(sdiffile)
    if infile.signature not in SDIF_NEWTYPES:
        return
    outfile = SdifFile(os.path.splitext(infile.name)[0] + '-R.sdif', 'w', infile.signature)
    if frame_types is not None or matrix_types is not None:
        raise NotImplemented    # TODO
    for frame0 in infile:
        frame1 = outfile.new_frame(frame0.signature, frame0.time)
        for matrix in frame0:
            frame1.add_matrix(matrix.signature, matrix.get_data())
        frame1.write()
    infilename = infile.name
    outfilename = outfile.name
    
    outfile.close()
    infile.close()
    if inplace:
        os.remove(infilename)
        os.rename(outfilename, infilename)

def write_metadata(sdif_filename, metadata={}, suffix='-M', inplace=False):
    """
    produce a copy of the sdif file with the metadata given. if there was any metadata
    already defined in the source file, it will be overwritten.
    
    """
    insdif = SdifFile(sdif_filename)
    if not inplace:
        outsdif = SdifFile(os.path.splitext(sdif_filename)[0] + suffix + ".sdif", 'w')
    else:
        import tempfile
        outsdif = SdifFile(tempfile.mktemp(), 'w')
    outsdif.add_NVT(metadata)
    # and now, clone everything
    outsdif.clone_type_definitions(insdif)
    outsdif.clone_frames(insdif)
    infile = insdif.name
    outfile = outsdif.name
    outsdif.close()
    insdif.close()
    if inplace:
        os.remove(infile)
        os.rename(outfile, infile)
        
