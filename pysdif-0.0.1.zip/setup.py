import os
import sys

from numpy.distutils.core import setup, Extension
from setuphelp import info_factory, NotFoundError

SDIF_MAJ_VERSION = 1

def configuration(parent_package='',top_path=None):
    from numpy.distutils.misc_util import Configuration
    confgr = Configuration('pysdif',parent_package,top_path)
    #if os.path.exists('pysdif.py'):
    #    os.remove('pysdif.py')

    # Check that sndfile can be found and get necessary informations
    #sf_info = info_factory('sdif', ['sdif'], ['sdif.h'], classname='SndfileInfo')()
    sf_info = info_factory('sdif', ['sdif'], ['sdif.h'])()
    try:
        sf_config = sf_info.get_info(2)
    except NotFoundError:
        raise NotFoundError("""\
sdif library not found.""")

    confgr.add_extension('_pysdif', ['_pysdif.c'], extra_info=sf_config)

    return confgr

if __name__ == "__main__":
    from sdif_setup import cython_setup
    cython_setup()
    from numpy.distutils.core import setup as numpy_setup
    config = configuration(top_path='').todict()
    numpy_setup(**config)
